/* ============================================================
   KREATOR — ui.js
   Renders all pages: home, creators, videos, chat, auth
   ============================================================ */

"use strict";

/* ── HOME PAGE ───────────────────────────────────────────────── */
function renderHome() {
  const videos   = VideoStore.published();
  const users    = Store.users.get();
  const creators = users.filter(u => u.role === "creator" && u.active);
  const user     = Auth.currentUser();

  // Stats
  document.getElementById("stat-creators").textContent = creators.length;
  document.getElementById("stat-videos").textContent   = UI.fmtNum(videos.length);
  document.getElementById("stat-viewers").textContent  = UI.fmtNum(users.filter(u=>u.role==="viewer"||u.role==="creator").length);

  // Featured creators (up to 3)
  const featEl = document.getElementById("home-featured-creators");
  const featured = creators.slice(0, 3);
  if (!featured.length) {
    featEl.innerHTML = `<div class="text-muted text-sm" style="grid-column:1/-1;padding:20px 0">No creators yet. Be the first!</div>`;
  } else {
    featEl.innerHTML = featured.map(c => creatorCardHTML(c, user)).join("");
  }

  // Latest free videos (up to 6)
  const freeVids = videos.filter(v => v.tier === "free").slice(-6).reverse();
  const vidEl = document.getElementById("home-latest-videos");
  if (!freeVids.length) {
    vidEl.innerHTML = `<div class="text-muted text-sm" style="grid-column:1/-1;padding:20px 0">No videos yet.</div>`;
  } else {
    vidEl.innerHTML = freeVids.map(v => videoCardHTML(v, user)).join("");
  }
}

/* ── CREATORS PAGE ───────────────────────────────────────────── */
function renderCreatorsPage(filter = "") {
  const users    = Store.users.get();
  const user     = Auth.currentUser();
  const creators = users.filter(u =>
    u.role === "creator" && u.active &&
    (u.name.toLowerCase().includes(filter.toLowerCase()) ||
     (u.category||"").toLowerCase().includes(filter.toLowerCase()))
  );

  const grid = document.getElementById("all-creators-grid");
  if (!creators.length) {
    grid.innerHTML = `<div class="text-muted text-sm" style="grid-column:1/-1;padding:20px 0">No creators found.</div>`;
    return;
  }
  grid.innerHTML = creators.map(c => creatorCardHTML(c, user)).join("");
}

function creatorCardHTML(c, user) {
  const videos   = VideoStore.byCreator(c.id).filter(v => v.published);
  const unlocked = user ? SubStore.hasChatAccess(user.id, c.id) : false;
  return `
  <div class="card creator-card card-hover" onclick="openCreatorProfile('${c.id}')">
    <div class="creator-card-top">
      <div class="avatar av-48" style="background:${c.color}22;color:${c.color}">${c.avatar}</div>
      <div class="creator-info">
        <div class="creator-name">${c.name}</div>
        <div class="creator-cat">${c.category||"Creator"}</div>
      </div>
    </div>
    <div class="creator-tags">
      ${(c.tags||[]).map(t=>`<span class="tag">${t}</span>`).join("")}
    </div>
    <div class="creator-footer">
      <span class="text-muted text-sm">${videos.length} video${videos.length!==1?"s":""}</span>
      ${unlocked
        ? `<span class="badge badge-green">✓ Chat Unlocked</span>`
        : `<span class="creator-price">$${c.chatPrice||10}/chat</span>`
      }
    </div>
  </div>`;
}

/* ── CREATOR PROFILE PAGE ────────────────────────────────────── */
let _profileCreatorId = null;

function openCreatorProfile(creatorId) {
  _profileCreatorId = creatorId;
  const users   = Store.users.get();
  const creator = users.find(u => u.id === creatorId);
  if (!creator) return;
  const user    = Auth.currentUser();
  const unlocked = user ? SubStore.hasChatAccess(user.id, creatorId) : false;
  const videos  = VideoStore.byCreator(creatorId).filter(v => v.published);

  // Avatar
  const av = document.getElementById("profile-av");
  av.className = "avatar av-72";
  av.style.background = creator.color + "22";
  av.style.color = creator.color;
  av.textContent = creator.avatar;

  document.getElementById("profile-name").textContent     = creator.name;
  document.getElementById("profile-category").textContent = creator.category || "Creator";
  document.getElementById("profile-bio").textContent      = creator.bio || "No bio yet.";
  document.getElementById("profile-vid-count").textContent = `${videos.length} video${videos.length!==1?"s":""}`;
  document.getElementById("profile-price").textContent    = `$${creator.chatPrice||10}`;

  // Unlock actions
  const actEl = document.getElementById("profile-unlock-actions");
  if (!user) {
    actEl.innerHTML = `<button class="btn btn-primary" onclick="showAuthModal('login')">Log in to Chat</button>`;
  } else if (user.id === creatorId) {
    actEl.innerHTML = `<span class="badge badge-blue">Your profile</span>`;
  } else if (unlocked) {
    actEl.innerHTML = `
      <button class="btn btn-primary" onclick="openChat('${creatorId}')">Open Chat ↗</button>
      <span class="badge badge-green">✓ Access granted</span>`;
  } else {
    actEl.innerHTML = `
      <button class="btn btn-primary" onclick="startChatPayment('${creatorId}')">
        <span style="font-size:15px;font-weight:700;background:linear-gradient(135deg,#4285F4,#34A853,#FBBC05,#EA4335);-webkit-background-clip:text;-webkit-text-fill-color:transparent">G</span>
        Pay $${creator.chatPrice||10} · Unlock Chat
      </button>`;
  }

  // Creator videos
  const vEl = document.getElementById("profile-videos-grid");
  if (!videos.length) {
    vEl.innerHTML = `<div class="text-muted text-sm" style="grid-column:1/-1;padding:16px 0">No videos published yet.</div>`;
  } else {
    vEl.innerHTML = videos.map(v => videoCardHTML(v, user)).join("");
  }

  // Show profile, hide others
  document.querySelectorAll(".page").forEach(p=>p.classList.remove("active"));
  document.getElementById("page-profile").classList.add("active");
  window.scrollTo({top:0,behavior:"smooth"});
}

/* ── VIDEO CARD HTML ─────────────────────────────────────────── */
function videoCardHTML(v, user) {
  const isPremium   = v.tier === "premium";
  const isGold      = v.tier === "gold";
  const hasAccess   = !isPremium && !isGold
    ? true
    : user ? SubStore.hasPremiumAccess(user.id) : false;

  const lockIcon = !hasAccess ? `<div class="play-circle">🔒</div>` : `<div class="play-circle">▶</div>`;
  const tierBadge = isGold    ? `<span class="badge badge-gold video-premium-badge">⭐ Gold</span>`
                  : isPremium ? `<span class="badge badge-purple video-premium-badge">💎 Premium</span>`
                  : "";
  return `
  <div class="card video-card card-hover" onclick="playVideo('${v.id}')">
    <div class="video-thumb">
      <div class="avatar av-56" style="background:${v.thumbColor}33;color:${v.thumbColor}">${v.thumbInitials}</div>
      <div class="play-overlay">${lockIcon}</div>
      ${tierBadge}
      <div class="video-dur">${v.duration}</div>
    </div>
    <div class="video-title">${v.title}</div>
    <div class="video-meta">${v.creatorName} · ${UI.fmtNum(v.views)} views · ${UI.fmtDate(v.uploadedAt)}</div>
  </div>`;
}

/* ── VIDEO PLAYER ────────────────────────────────────────────── */
function playVideo(videoId) {
  const v    = VideoStore.byId(videoId);
  const user = Auth.currentUser();
  if (!v) return;

  const needsSub = v.tier === "gold" || v.tier === "premium";
  if (needsSub && (!user || !SubStore.hasPremiumAccess(user.id))) {
    Payment.openPremiumModal();
    Payment.waitForPayment().then(res => {
      if (res.ok) { Payment.close(); playVideo(videoId); }
    });
    return;
  }

  VideoStore.incrementView(videoId);

  const modal = document.getElementById("video-player-modal");
  document.getElementById("vp-title").textContent  = v.title;
  document.getElementById("vp-meta").textContent   = `${v.creatorName} · ${v.description}`;
  document.getElementById("vp-av").className       = "avatar av-40";
  document.getElementById("vp-av").style.background= v.thumbColor + "22";
  document.getElementById("vp-av").style.color     = v.thumbColor;
  document.getElementById("vp-av").textContent     = v.thumbInitials;
  document.getElementById("vp-duration").textContent = v.duration;
  document.getElementById("vp-views").textContent  = UI.fmtNum(v.views) + " views";
  modal.classList.add("open");
  document.body.style.overflow = "hidden";
}

/* ── CHAT PAGE ───────────────────────────────────────────────── */
let _chatWithId = null;

function openChat(creatorId) {
  const user = Auth.currentUser();
  if (!user) { showAuthModal("login"); return; }
  if (!SubStore.hasChatAccess(user.id, creatorId)) {
    startChatPayment(creatorId);
    return;
  }
  _chatWithId = creatorId;
  renderChatUI();
  Router.go("chat");
}

function renderChatUI() {
  const user = Auth.currentUser();
  if (!user || !_chatWithId) {
    document.getElementById("chat-empty-state").style.display = "flex";
    document.getElementById("chat-container").style.display   = "none";
    return;
  }
  const users   = Store.users.get();
  const creator = users.find(u => u.id === _chatWithId);
  if (!creator) return;

  document.getElementById("chat-empty-state").style.display = "none";
  document.getElementById("chat-container").style.display   = "flex";

  const cav = document.getElementById("chat-av");
  cav.className = "avatar av-40";
  cav.style.background = creator.color + "22";
  cav.style.color = creator.color;
  cav.textContent = creator.avatar;
  document.getElementById("chat-with-name").textContent = creator.name;

  Messaging.markRead(_chatWithId, user.id);
  refreshMessages();
}

function refreshMessages() {
  const user = Auth.currentUser();
  if (!user || !_chatWithId) return;
  const msgs = Messaging.thread(user.id, _chatWithId);
  const box  = document.getElementById("chat-messages-box");
  box.innerHTML = `<div class="chat-sys">Private session · Encrypted</div>`;
  if (!msgs.length) {
    box.innerHTML += `<div style="text-align:center;color:var(--muted2);font-size:14px;margin-top:30px">Start the conversation 👋</div>`;
  } else {
    msgs.forEach(m => {
      const isMe = m.from === user.id;
      box.innerHTML += `
        <div class="msg-row ${isMe?"me":""}">
          <div class="bubble ${isMe?"me":"them"}">
            ${m.text}
            <div class="bubble-time">${UI.fmtTime(m.time)}</div>
          </div>
        </div>`;
    });
  }
  box.scrollTop = box.scrollHeight;
}

function sendChatMessage() {
  const user  = Auth.currentUser();
  const input = document.getElementById("chat-msg-input");
  if (!user || !_chatWithId || !input.value.trim()) return;
  Messaging.send(user.id, _chatWithId, input.value.trim());
  input.value = "";
  refreshMessages();
}

async function startChatPayment(creatorId) {
  const user = Auth.currentUser();
  if (!user) { showAuthModal("login"); return; }
  const users   = Store.users.get();
  const creator = users.find(u => u.id === creatorId);
  if (!creator) return;
  Payment.openChatPayModal({
    id:        creator.id,
    name:      creator.name,
    category:  creator.category || "Creator",
    avatar:    creator.avatar,
    color:     creator.color,
    chatPrice: creator.chatPrice || 10,
  });
  const res = await Payment.waitForPayment();
  if (res?.ok) {
    setTimeout(() => {
      Payment.close();
      openChat(creatorId);
    }, 1500);
  }
}

/* ── VIDEOS PAGE ─────────────────────────────────────────────── */
function renderVideosPage(filter = "", tierFilter = "all") {
  const user   = Auth.currentUser();
  let   videos = VideoStore.published();

  if (filter) {
    const q = filter.toLowerCase();
    videos = videos.filter(v =>
      v.title.toLowerCase().includes(q) ||
      v.creatorName.toLowerCase().includes(q) ||
      v.category.toLowerCase().includes(q)
    );
  }
  if (tierFilter !== "all") videos = videos.filter(v => v.tier === tierFilter);
  videos = videos.slice().reverse();

  const grid = document.getElementById("videos-page-grid");
  if (!videos.length) {
    grid.innerHTML = `<div class="text-muted text-sm" style="grid-column:1/-1;padding:20px 0">No videos found.</div>`;
    return;
  }
  grid.innerHTML = videos.map(v => videoCardHTML(v, user)).join("");
}

/* ── AUTH MODAL ──────────────────────────────────────────────── */
function showAuthModal(tab = "login") {
  document.getElementById("auth-modal").classList.add("open");
  document.body.style.overflow = "hidden";
  switchAuthTab(tab);
}

function switchAuthTab(tab) {
  document.getElementById("auth-login-form").style.display  = tab === "login"    ? "block" : "none";
  document.getElementById("auth-signup-form").style.display = tab === "signup"   ? "block" : "none";
  document.querySelectorAll(".auth-tab-btn").forEach(b => {
    b.classList.toggle("active", b.dataset.tab === tab);
  });
}

async function handleLogin(e) {
  e.preventDefault();
  const email = document.getElementById("login-email").value.trim();
  const pw    = document.getElementById("login-pw").value;
  const errEl = document.getElementById("login-error");
  errEl.classList.remove("show");
  const btn = e.target.querySelector("button[type=submit]");
  btn.disabled = true; btn.textContent = "Logging in…";
  const res = await Auth.login(email, pw);
  btn.disabled = false; btn.textContent = "Log In";
  if (!res.ok) { errEl.textContent = res.error; errEl.classList.add("show"); return; }
  document.getElementById("auth-modal").classList.remove("open");
  document.body.style.overflow = "";
  UI.toast(`Welcome back, ${res.user.name}!`, "success");
  initApp();
}

async function handleSignup(e) {
  e.preventDefault();
  const name  = document.getElementById("signup-name").value.trim();
  const email = document.getElementById("signup-email").value.trim();
  const pw    = document.getElementById("signup-pw").value;
  const role  = document.getElementById("signup-role").value;
  const errEl = document.getElementById("signup-error");
  errEl.classList.remove("show");
  const btn = e.target.querySelector("button[type=submit]");
  btn.disabled = true; btn.textContent = "Creating account…";
  const res = await Auth.register({ name, email, password:pw, role });
  btn.disabled = false; btn.textContent = "Create Account";
  if (!res.ok) { errEl.textContent = res.error; errEl.classList.add("show"); return; }
  // auto-login
  await Auth.login(email, pw);
  document.getElementById("auth-modal").classList.remove("open");
  document.body.style.overflow = "";
  UI.toast(`Welcome to KREATOR, ${res.user.name}! 🎉`, "success");
  initApp();
}

/* ── NAV RENDERING (per auth state) ─────────────────────────── */
function renderNav() {
  const user = Auth.currentUser();
  const headerActions = document.getElementById("header-actions");

  if (!user) {
    headerActions.innerHTML = `
      <button class="btn btn-ghost btn-sm" onclick="showAuthModal('login')">Log In</button>
      <button class="btn btn-primary btn-sm" onclick="showAuthModal('signup')">Sign Up Free</button>`;
  } else {
    const dashRoute = user.role === "admin" ? "admin-dash" : user.role === "creator" ? "creator-dash" : null;
    headerActions.innerHTML = `
      ${dashRoute ? `<button class="btn btn-ghost btn-sm" onclick="Router.go('${dashRoute}')">Dashboard</button>` : ""}
      <div class="avatar av-32" style="background:${user.color}22;color:${user.color};cursor:pointer" onclick="Router.go('settings')">${user.avatar}</div>
      <button class="btn btn-ghost btn-sm btn-icon" onclick="Auth.logout()" title="Log out">⎋</button>`;
  }

  // Mobile nav same
  const mobileHeaderActions = document.getElementById("mobile-header-actions");
  if (mobileHeaderActions) mobileHeaderActions.innerHTML = headerActions.innerHTML;
}

/* ── MOBILE NAV ──────────────────────────────────────────────── */
function toggleMobileNav() {
  const nav = document.getElementById("mobile-nav");
  const btn = document.getElementById("hamburger");
  nav.classList.toggle("open");
  btn.classList.toggle("open");
}
function closeMobileNav() {
  document.getElementById("mobile-nav")?.classList.remove("open");
  document.getElementById("hamburger")?.classList.remove("open");
}
