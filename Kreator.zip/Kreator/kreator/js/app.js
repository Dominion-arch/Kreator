/* ============================================================
   KREATOR — app.js
   Handles: videos, subscriptions, payments, messaging, UI
   ============================================================ */

"use strict";

/* ── VIDEO STORE ─────────────────────────────────────────────── */
const VideoStore = (() => {

  function add(video) {
    const videos = Store.videos.get();
    const v = {
      id:          Security.generateId(),
      creatorId:   video.creatorId,
      creatorName: Security.sanitize(video.creatorName),
      title:       Security.sanitize(video.title),
      description: Security.sanitize(video.description || ""),
      category:    Security.sanitize(video.category || ""),
      tags:        (video.tags||[]).map(t=>Security.sanitize(t)).slice(0,5),
      tier:        "free",          // free | gold | premium
      fileName:    video.fileName || "",
      fileSize:    video.fileSize  || 0,
      duration:    video.duration  || "0:00",
      thumbColor:  video.thumbColor|| "#E8C547",
      thumbInitials: video.thumbInitials || "VD",
      views:       0,
      uploadedAt:  new Date().toISOString(),
      published:   false,
      flagged:     false,
    };
    videos.push(v);
    Store.videos.set(videos);
    return v;
  }

  function update(id, fields, requesterId, requesterRole) {
    const videos = Store.videos.get();
    const idx    = videos.findIndex(v => v.id === id);
    if (idx === -1) return { ok:false, error:"Video not found." };
    const v = videos[idx];
    // Only creator-owner or admin may edit
    if (requesterRole !== "admin" && v.creatorId !== requesterId)
      return { ok:false, error:"Unauthorised." };
    // Admin-only fields
    if (requesterRole === "admin" && fields.tier !== undefined) v.tier = fields.tier;
    if (requesterRole === "admin" && fields.published !== undefined) v.published = fields.published;
    if (requesterRole === "admin" && fields.flagged !== undefined) v.flagged = fields.flagged;
    // Creator + admin fields
    const editable = ["title","description","category","tags"];
    editable.forEach(k => { if (fields[k] !== undefined) v[k] = fields[k]; });
    videos[idx] = v;
    Store.videos.set(videos);
    return { ok:true, video:v };
  }

  function remove(id, requesterId, requesterRole) {
    let videos = Store.videos.get();
    const v = videos.find(x => x.id === id);
    if (!v) return { ok:false, error:"Not found." };
    if (requesterRole !== "admin" && v.creatorId !== requesterId)
      return { ok:false, error:"Unauthorised." };
    videos = videos.filter(x => x.id !== id);
    Store.videos.set(videos);
    return { ok:true };
  }

  function incrementView(id) {
    const videos = Store.videos.get();
    const idx = videos.findIndex(v => v.id === id);
    if (idx !== -1) { videos[idx].views++; Store.videos.set(videos); }
  }

  function all()           { return Store.videos.get(); }
  function published()     { return Store.videos.get().filter(v => v.published && !v.flagged); }
  function byCreator(cid)  { return Store.videos.get().filter(v => v.creatorId === cid); }
  function byId(id)        { return Store.videos.get().find(v => v.id === id) || null; }

  return { add, update, remove, incrementView, all, published, byCreator, byId };
})();

/* ── SUBSCRIPTION / UNLOCK STORE ────────────────────────────── */
const SubStore = (() => {

  function hasChatAccess(viewerId, creatorId) {
    const subs = Store.subs.get();
    const now  = Date.now();
    return subs.some(s =>
      s.viewerId === viewerId && s.creatorId === creatorId &&
      s.type === "chat" && s.expires > now
    );
  }

  function hasPremiumAccess(viewerId) {
    const subs = Store.subs.get();
    const now  = Date.now();
    return subs.some(s => s.viewerId === viewerId && s.type === "premium" && s.expires > now);
  }

  function addChatSub(viewerId, creatorId, price) {
    const subs = Store.subs.get();
    const txId = Security.generateId();
    subs.push({
      id:        txId,
      viewerId,  creatorId,
      type:      "chat",
      price,
      paidAt:    new Date().toISOString(),
      expires:   Date.now() + 7 * 24 * 60 * 60 * 1000,
    });
    Store.subs.set(subs);
    // Record earnings
    const earnings = Store.earnings.get();
    earnings.push({ id:txId, creatorId, viewerId, amount:price, type:"chat", date:new Date().toISOString() });
    Store.earnings.set(earnings);
    return txId;
  }

  function addPremiumSub(viewerId, price) {
    const subs = Store.subs.get();
    subs.push({
      id:       Security.generateId(),
      viewerId, creatorId:null,
      type:     "premium",
      price,
      paidAt:   new Date().toISOString(),
      expires:  Date.now() + 30 * 24 * 60 * 60 * 1000,
    });
    Store.subs.set(subs);
  }

  function chatSubsForCreator(creatorId) {
    return Store.subs.get().filter(s => s.creatorId === creatorId && s.type === "chat");
  }

  function allSubs()  { return Store.subs.get(); }
  function earnings() { return Store.earnings.get(); }

  function creatorTotalEarnings(creatorId) {
    return Store.earnings.get()
      .filter(e => e.creatorId === creatorId)
      .reduce((sum, e) => sum + (e.amount||0), 0);
  }

  return { hasChatAccess, hasPremiumAccess, addChatSub, addPremiumSub,
           chatSubsForCreator, allSubs, earnings, creatorTotalEarnings };
})();

/* ── MESSAGING ───────────────────────────────────────────────── */
const Messaging = (() => {

  function threadKey(a, b) {
    return [a, b].sort().join("__");
  }

  function send(fromId, toId, text) {
    const clean = Security.sanitize(text);
    if (!clean) return null;
    const msgs = Store.messages.get();
    const key  = threadKey(fromId, toId);
    if (!msgs[key]) msgs[key] = [];
    const msg = {
      id:   Security.generateId(),
      from: fromId,
      to:   toId,
      text: clean,
      time: new Date().toISOString(),
      read: false,
    };
    msgs[key].push(msg);
    Store.messages.set(msgs);
    return msg;
  }

  function thread(a, b) {
    const msgs = Store.messages.get();
    return msgs[threadKey(a, b)] || [];
  }

  function markRead(fromId, toId) {
    const msgs = Store.messages.get();
    const key  = threadKey(fromId, toId);
    if (msgs[key]) {
      msgs[key].forEach(m => { if (m.to === toId) m.read = true; });
      Store.messages.set(msgs);
    }
  }

  function unreadCount(userId) {
    const msgs = Store.messages.get();
    return Object.values(msgs).flat().filter(m => m.to === userId && !m.read).length;
  }

  return { send, thread, markRead, unreadCount };
})();

/* ── UI HELPERS ─────────────────────────────────────────────── */
const UI = (() => {

  /* Toast */
  function toast(msg, type = "info", duration = 3500) {
    const container = document.getElementById("toast-container");
    if (!container) return;
    const icons = { success:"✅", error:"❌", info:"💡" };
    const t = document.createElement("div");
    t.className = `toast ${type}`;
    t.innerHTML = `<span class="toast-icon">${icons[type]||"💡"}</span><span>${msg}</span>`;
    container.appendChild(t);
    setTimeout(() => {
      t.classList.add("toast-out");
      setTimeout(() => t.remove(), 300);
    }, duration);
  }

  /* Avatar element */
  function avatarEl(initials, color, sizeClass = "av-40") {
    return `<div class="avatar ${sizeClass}" style="background:${color}22;color:${color}">${initials}</div>`;
  }

  /* Format date */
  function fmtDate(iso) {
    if (!iso) return "—";
    return new Date(iso).toLocaleDateString("en-GB", { day:"2-digit", month:"short", year:"numeric" });
  }

  function fmtTime(iso) {
    if (!iso) return "";
    return new Date(iso).toLocaleTimeString([], { hour:"2-digit", minute:"2-digit" });
  }

  function fmtNum(n) {
    if (n >= 1000000) return (n/1000000).toFixed(1) + "M";
    if (n >= 1000)    return (n/1000).toFixed(1) + "K";
    return String(n);
  }

  /* Confirm dialog using modal */
  function confirm(msg, cb) {
    const existing = document.getElementById("_confirm_modal");
    if (existing) existing.remove();
    const d = document.createElement("div");
    d.id = "_confirm_modal";
    d.className = "modal-overlay open";
    d.innerHTML = `
      <div class="modal-box" style="max-width:360px">
        <p style="margin-bottom:20px;font-size:15px">${msg}</p>
        <div class="flex gap-10" style="justify-content:flex-end">
          <button class="btn btn-ghost btn-sm" id="_conf_no">Cancel</button>
          <button class="btn btn-danger btn-sm" id="_conf_yes">Confirm</button>
        </div>
      </div>`;
    document.body.appendChild(d);
    document.getElementById("_conf_yes").onclick = () => { d.remove(); cb(true); };
    document.getElementById("_conf_no").onclick  = () => { d.remove(); cb(false); };
    d.onclick = (e) => { if (e.target === d) d.remove(); };
  }

  return { toast, avatarEl, fmtDate, fmtTime, fmtNum, confirm };
})();

/* ── ROUTER / PAGE MANAGER ───────────────────────────────────── */
const Router = (() => {
  let current = null;
  const callbacks = {};

  function on(page, cb) { callbacks[page] = cb; }

  function go(page) {
    document.querySelectorAll(".page").forEach(p => p.classList.remove("active"));
    const el = document.getElementById("page-" + page);
    if (el) el.classList.add("active");
    current = page;

    // sync all nav buttons
    document.querySelectorAll("[data-page]").forEach(b => {
      b.classList.toggle("active", b.dataset.page === page);
    });

    if (callbacks[page]) callbacks[page]();
    window.scrollTo({ top:0, behavior:"smooth" });
    closeMobileNav();
  }

  function getCurrent() { return current; }
  return { on, go, getCurrent };
})();

/* ── PAYMENT FLOW ────────────────────────────────────────────── */
const Payment = (() => {
  let _resolve = null;
  let _meta    = null;

  function openChatPayModal(creator) {
    _meta = { type:"chat", creator };
    const m = document.getElementById("pay-modal");
    document.getElementById("pay-form-section").style.display = "block";
    document.getElementById("pay-processing-section").style.display = "none";
    document.getElementById("pay-success-section").style.display = "none";

    document.getElementById("pay-modal-title").textContent  = `Unlock Chat with ${creator.name}`;
    document.getElementById("pay-creator-name").textContent = creator.name;
    document.getElementById("pay-creator-cat").textContent  = creator.category;
    document.getElementById("pay-creator-av").className     = `avatar av-44`;
    document.getElementById("pay-creator-av").style.background = creator.color + "22";
    document.getElementById("pay-creator-av").style.color   = creator.color;
    document.getElementById("pay-creator-av").textContent   = creator.avatar;
    document.getElementById("pay-line-item").textContent    = `$${creator.chatPrice}.00`;
    document.getElementById("pay-total-val").textContent    = `$${creator.chatPrice}.00`;
    document.getElementById("pay-desc").textContent = `7-day private messaging access with ${creator.name}.`;
    m.classList.add("open");
    document.body.style.overflow = "hidden";
  }

  function openPremiumModal() {
    _meta = { type:"premium" };
    const m = document.getElementById("pay-modal");
    document.getElementById("pay-form-section").style.display = "block";
    document.getElementById("pay-processing-section").style.display = "none";
    document.getElementById("pay-success-section").style.display = "none";

    document.getElementById("pay-modal-title").textContent  = "Subscribe to Premium";
    document.getElementById("pay-creator-name").textContent = "KREATOR Premium";
    document.getElementById("pay-creator-cat").textContent  = "All gold & premium videos · 30 days";
    document.getElementById("pay-creator-av").textContent   = "⭐";
    document.getElementById("pay-creator-av").style.background = "rgba(232,197,71,.15)";
    document.getElementById("pay-creator-av").style.color   = "#E8C547";
    document.getElementById("pay-line-item").textContent    = "$9.99";
    document.getElementById("pay-total-val").textContent    = "$9.99";
    document.getElementById("pay-desc").textContent         = "Unlock all gold & premium videos for 30 days.";
    m.classList.add("open");
    document.body.style.overflow = "hidden";
  }

  function close() {
    document.getElementById("pay-modal").classList.remove("open");
    document.body.style.overflow = "";
    _meta = null;
  }

  async function process() {
    const user = Auth.currentUser();
    if (!user) { UI.toast("Please log in first.", "error"); close(); return; }

    document.getElementById("pay-form-section").style.display = "none";
    document.getElementById("pay-processing-section").style.display = "block";

    await new Promise(r => setTimeout(r, 2200)); // simulate Google Pay

    if (_meta.type === "chat") {
      SubStore.addChatSub(user.id, _meta.creator.id, _meta.creator.chatPrice);
      document.getElementById("pay-processing-section").style.display = "none";
      document.getElementById("pay-success-section").style.display = "block";
      document.getElementById("pay-success-msg").textContent =
        `You now have 7-day chat access with ${_meta.creator.name}!`;
      if (_resolve) _resolve({ ok:true, type:"chat", creatorId:_meta.creator.id });
    } else {
      SubStore.addPremiumSub(user.id, 9.99);
      document.getElementById("pay-processing-section").style.display = "none";
      document.getElementById("pay-success-section").style.display = "block";
      document.getElementById("pay-success-msg").textContent =
        "You now have 30-day access to all premium & gold content!";
      if (_resolve) _resolve({ ok:true, type:"premium" });
    }
  }

  function waitForPayment() {
    return new Promise(res => { _resolve = res; });
  }

  return { openChatPayModal, openPremiumModal, close, process, waitForPayment };
})();
