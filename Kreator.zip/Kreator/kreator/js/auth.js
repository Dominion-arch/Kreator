/* ============================================================
   KREATOR — auth.js   (runs before app.js)
   Handles: account creation, login, sessions, security
   ============================================================ */

"use strict";

/* ── SECURITY HELPERS ───────────────────────────────────────── */
const Security = (() => {

  /* Simple PBKDF2-style hash using Web Crypto (async) */
  async function hashPassword(password, salt) {
    const enc = new TextEncoder();
    const keyMat = await crypto.subtle.importKey(
      "raw", enc.encode(password), "PBKDF2", false, ["deriveBits"]
    );
    const bits = await crypto.subtle.deriveBits(
      { name:"PBKDF2", salt:enc.encode(salt), iterations:100000, hash:"SHA-256" },
      keyMat, 256
    );
    return Array.from(new Uint8Array(bits)).map(b=>b.toString(16).padStart(2,"0")).join("");
  }

  function generateSalt() {
    return Array.from(crypto.getRandomValues(new Uint8Array(16)))
      .map(b=>b.toString(16).padStart(2,"0")).join("");
  }

  function generateId() {
    return Date.now().toString(36) + Math.random().toString(36).slice(2, 9);
  }

  /* Sanitise all user-supplied strings before storing / rendering */
  function sanitize(str) {
    if (typeof str !== "string") return "";
    return str
      .replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;")
      .replace(/"/g,"&quot;").replace(/'/g,"&#x27;").trim();
  }

  /* Rate-limit login attempts per username (in-memory) */
  const attempts = {};
  function checkRateLimit(key) {
    const now = Date.now();
    if (!attempts[key]) attempts[key] = { count:0, reset: now + 60000 };
    if (now > attempts[key].reset) { attempts[key] = { count:0, reset: now + 60000 }; }
    attempts[key].count++;
    return attempts[key].count <= 5; // max 5 per minute
  }
  function clearRateLimit(key) { delete attempts[key]; }

  /* Session token */
  function generateToken() {
    return Array.from(crypto.getRandomValues(new Uint8Array(32)))
      .map(b=>b.toString(16).padStart(2,"0")).join("");
  }

  /* Basic input validation */
  function validateEmail(email) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  }
  function validatePassword(pw) {
    if (pw.length < 8) return "Password must be at least 8 characters.";
    if (!/[A-Z]/.test(pw)) return "Password must contain an uppercase letter.";
    if (!/[0-9]/.test(pw)) return "Password must contain a number.";
    return null;
  }

  return { hashPassword, generateSalt, generateId, sanitize,
           checkRateLimit, clearRateLimit, generateToken,
           validateEmail, validatePassword };
})();

/* ── DATA STORE (localStorage) ──────────────────────────────── */
const Store = (() => {
  const PREFIX = "kreator_";

  function get(key) {
    try { return JSON.parse(localStorage.getItem(PREFIX + key)); }
    catch { return null; }
  }
  function set(key, val) {
    try { localStorage.setItem(PREFIX + key, JSON.stringify(val)); return true; }
    catch { return false; }
  }
  function remove(key) { localStorage.removeItem(PREFIX + key); }

  /* Namespaced helpers */
  const users    = { get: ()=>get("users")    ||[], set: v=>set("users",v) };
  const videos   = { get: ()=>get("videos")   ||[], set: v=>set("videos",v) };
  const messages = { get: ()=>get("messages") ||{}, set: v=>set("messages",v) };
  const session  = { get: ()=>get("session"),        set: v=>set("session",v), clear:()=>remove("session") };
  const subs     = { get: ()=>get("subs")     ||[], set: v=>set("subs",v) };
  const earnings = { get: ()=>get("earnings") ||[], set: v=>set("earnings",v) };

  return { users, videos, messages, session, subs, earnings };
})();

/* ── AUTH ────────────────────────────────────────────────────── */
const Auth = (() => {

  /* Seed admin account on first load */
  async function seedAdmin() {
    const users = Store.users.get();
    if (users.find(u => u.role === "admin")) return;
    const salt = Security.generateSalt();
    const hash = await Security.hashPassword("Admin@2026", salt);
    users.push({
      id:       "admin_0",
      name:     "Admin",
      email:    "admin@kreator.app",
      salt,
      hash,
      role:     "admin",
      avatar:   "AD",
      color:    "#E8C547",
      joined:   new Date().toISOString(),
      active:   true,
      bio:      "Platform administrator.",
      category: "",
    });
    Store.users.set(users);
  }

  async function register({ name, email, password, role }) {
    const users = Store.users.get();

    if (!Security.validateEmail(email))
      return { ok:false, error:"Invalid email address." };

    const pwErr = Security.validatePassword(password);
    if (pwErr) return { ok:false, error:pwErr };

    if (users.find(u => u.email.toLowerCase() === email.toLowerCase()))
      return { ok:false, error:"An account with this email already exists." };

    const salt  = Security.generateSalt();
    const hash  = await Security.hashPassword(password, salt);
    const initials = name.trim().split(" ").map(w=>w[0]?.toUpperCase()||"").slice(0,2).join("") || "U";
    const colors = ["#E8C547","#47B8E8","#E847A0","#47E8A0","#E88047","#A047E8","#47E8E8","#E84747"];
    const color  = colors[Math.floor(Math.random() * colors.length)];

    const user = {
      id:       Security.generateId(),
      name:     Security.sanitize(name),
      email:    email.toLowerCase(),
      salt, hash,
      role:     role === "creator" ? "creator" : "viewer",
      avatar:   initials,
      color,
      joined:   new Date().toISOString(),
      active:   true,
      bio:      "",
      category: "",
      subscribers: 0,
    };

    users.push(user);
    Store.users.set(users);
    return { ok:true, user: publicUser(user) };
  }

  async function login(email, password) {
    if (!Security.checkRateLimit(email.toLowerCase()))
      return { ok:false, error:"Too many login attempts. Please wait 1 minute." };

    const users = Store.users.get();
    const user  = users.find(u => u.email.toLowerCase() === email.toLowerCase());
    if (!user) return { ok:false, error:"Invalid email or password." };
    if (!user.active) return { ok:false, error:"This account has been suspended." };

    const hash = await Security.hashPassword(password, user.salt);
    if (hash !== user.hash) return { ok:false, error:"Invalid email or password." };

    Security.clearRateLimit(email.toLowerCase());

    const token = Security.generateToken();
    const session = { userId:user.id, token, role:user.role, expires: Date.now() + 7*24*60*60*1000 };
    Store.session.set(session);

    return { ok:true, user: publicUser(user), session };
  }

  function logout() {
    Store.session.clear();
    window.location.reload();
  }

  function currentUser() {
    const session = Store.session.get();
    if (!session || Date.now() > session.expires) {
      Store.session.clear();
      return null;
    }
    const users = Store.users.get();
    const user  = users.find(u => u.id === session.userId);
    if (!user || !user.active) { Store.session.clear(); return null; }
    return publicUser(user);
  }

  function publicUser(u) {
    return {
      id:u.id, name:u.name, email:u.email, role:u.role,
      avatar:u.avatar, color:u.color, joined:u.joined,
      bio:u.bio||"", category:u.category||"", active:u.active,
      subscribers:u.subscribers||0,
    };
  }

  function updateProfile(id, fields) {
    const users = Store.users.get();
    const idx   = users.findIndex(u => u.id === id);
    if (idx === -1) return { ok:false, error:"User not found." };
    const allowed = ["name","bio","category","avatar","color"];
    allowed.forEach(k => {
      if (fields[k] !== undefined)
        users[idx][k] = Security.sanitize(String(fields[k]));
    });
    Store.users.set(users);
    return { ok:true };
  }

  return { seedAdmin, register, login, logout, currentUser, updateProfile };
})();
