/* ============================================================
   KREATOR — main.js
   Entry point: boots app, wires router, settings page
   ============================================================ */

"use strict";

/* ── HELPERS ─────────────────────────────────────────────────── */
function togglePwVis(inputId, iconEl) {
  const inp = document.getElementById(inputId);
  if (!inp) return;
  inp.type = inp.type === "password" ? "text" : "password";
  iconEl.textContent = inp.type === "password" ? "👁" : "🙈";
}

function saveAccountSettings(e) {
  e.preventDefault();
  const user = Auth.currentUser();
  if (!user) return;
  Auth.updateProfile(user.id, {
    name:     document.getElementById("acc-name").value.trim(),
    bio:      document.getElementById("acc-bio").value.trim(),
    category: document.getElementById("acc-category").value.trim(),
  });
  UI.toast("Settings saved.", "success");
  renderNav();
}

function renderSettingsPage() {
  const user = Auth.currentUser();
  if (!user) { Router.go("home"); return; }
  document.getElementById("acc-name").value     = user.name;
  document.getElementById("acc-bio").value      = user.bio || "";
  document.getElementById("acc-category").value = user.category || "";
}

/* ── CLOSE MODALS ON OVERLAY CLICK ──────────────────────────── */
document.querySelectorAll(".modal-overlay").forEach(overlay => {
  overlay.addEventListener("click", function (e) {
    if (e.target === this) {
      this.classList.remove("open");
      document.body.style.overflow = "";
    }
  });
});

/* ── PAYMENT MODAL PAY BUTTON ────────────────────────────────── */
document.addEventListener("DOMContentLoaded", () => {
  const payBtn = document.getElementById("pay-process-btn");
  if (payBtn) payBtn.addEventListener("click", Payment.process);
});

/* ── ROUTER SETUP ────────────────────────────────────────────── */
Router.on("home",        () => renderHome());
Router.on("creators",    () => renderCreatorsPage());
Router.on("videos",      () => renderVideosPage());
Router.on("chat",        () => renderChatUI());
Router.on("profile",     () => {});  // handled by openCreatorProfile()
Router.on("settings",    () => renderSettingsPage());
Router.on("creator-dash",() => CreatorDash.init());
Router.on("admin-dash",  () => AdminDash.init());

/* ── KEYBOARD SHORTCUTS ──────────────────────────────────────── */
document.addEventListener("keydown", e => {
  if (e.key === "Escape") {
    document.querySelectorAll(".modal-overlay.open").forEach(m => {
      m.classList.remove("open");
      document.body.style.overflow = "";
    });
    document.getElementById("mobile-nav")?.classList.remove("open");
    document.getElementById("hamburger")?.classList.remove("open");
  }
});

/* ── SESSION EXPIRY MONITOR ──────────────────────────────────── */
setInterval(() => {
  const sess = Store.session.get();
  if (sess && Date.now() > sess.expires) {
    Store.session.clear();
    UI.toast("Your session expired. Please log in again.", "info");
    initApp();
  }
}, 60 * 1000);

/* ── MAIN INIT ───────────────────────────────────────────────── */
async function initApp() {
  await Auth.seedAdmin();

  const user = Auth.currentUser();
  renderNav();

  // Sync mobile nav actions
  const mobileActions = document.getElementById("mobile-header-actions");
  if (mobileActions) {
    mobileActions.innerHTML = document.getElementById("header-actions").innerHTML;
  }

  // Build public nav buttons
  const pubNavPages = ["home", "creators", "videos", "chat"];
  pubNavPages.forEach(page => {
    document.querySelectorAll(`[data-page="${page}"]`).forEach(btn => {
      btn.onclick = () => Router.go(page);
    });
  });

  // Redirect to appropriate starting page
  const current = Router.getCurrent();
  if (!current) Router.go("home");
  else Router.go(current);
}

/* ── BOOT ────────────────────────────────────────────────────── */
document.addEventListener("DOMContentLoaded", initApp);
