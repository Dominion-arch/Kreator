/* ============================================================
   KREATOR — dashboards.js
   Creator Dashboard + Admin Dashboard
   ============================================================ */

"use strict";

/* ═══════════════════════════════════════════════════════════════
   CREATOR DASHBOARD
═══════════════════════════════════════════════════════════════ */
const CreatorDash = (() => {

  let _activeSection = "cd-overview";

  function init() {
    const user = Auth.currentUser();
    if (!user || (user.role !== "creator" && user.role !== "admin")) {
      Router.go("home"); return;
    }
    renderSection(_activeSection);
  }

  function renderSection(section) {
    _activeSection = section;
    document.querySelectorAll("#creator-dash-content .dash-section").forEach(s => {
      s.style.display = s.id === section ? "block" : "none";
    });
    document.querySelectorAll("#creator-sidebar .sidebar-btn").forEach(b => {
      b.classList.toggle("active", b.dataset.section === section);
    });
    const renders = {
      "cd-overview":  renderOverview,
      "cd-videos":    renderMyVideos,
      "cd-upload":    renderUpload,
      "cd-messages":  renderCreatorMessages,
      "cd-earnings":  renderEarnings,
      "cd-settings":  renderCreatorSettings,
    };
    if (renders[section]) renders[section]();
  }

  /* ── OVERVIEW ────────────────────────────────────────────── */
  function renderOverview() {
    const user    = Auth.currentUser();
    const videos  = VideoStore.byCreator(user.id);
    const pubVids = videos.filter(v => v.published);
    const totalViews = videos.reduce((s,v)=>s+v.views,0);
    const subs    = SubStore.chatSubsForCreator(user.id);
    const earned  = SubStore.creatorTotalEarnings(user.id);

    document.getElementById("cd-stat-videos").textContent  = pubVids.length;
    document.getElementById("cd-stat-views").textContent   = UI.fmtNum(totalViews);
    document.getElementById("cd-stat-chats").textContent   = subs.length;
    document.getElementById("cd-stat-earned").textContent  = `$${earned.toFixed(2)}`;

    // Recent videos
    const recEl = document.getElementById("cd-recent-videos");
    const recent = videos.slice().reverse().slice(0,5);
    if (!recent.length) {
      recEl.innerHTML = `<div class="text-muted text-sm" style="padding:16px 0">No videos uploaded yet.</div>`;
    } else {
      recEl.innerHTML = recent.map(v => `
        <div class="card vid-edit-card" style="margin-bottom:10px">
          <div class="vid-edit-thumb" style="background:${v.thumbColor}22;color:${v.thumbColor};font-size:20px">${v.thumbInitials}</div>
          <div class="vid-edit-info">
            <div class="vid-edit-title">${v.title}</div>
            <div class="vid-edit-meta">${UI.fmtNum(v.views)} views · ${UI.fmtDate(v.uploadedAt)}</div>
          </div>
          <div class="vid-edit-actions">
            ${v.published ? `<span class="badge badge-green">Published</span>` : `<span class="badge badge-muted">Draft</span>`}
            <span class="badge badge-${v.tier==="gold"?"gold":v.tier==="premium"?"purple":"muted"}">${v.tier}</span>
          </div>
        </div>`).join("");
    }

    // Recent chat subs
    const recentSubs = subs.slice().reverse().slice(0,5);
    const subEl = document.getElementById("cd-recent-subs");
    if (!recentSubs.length) {
      subEl.innerHTML = `<div class="text-muted text-sm" style="padding:16px 0">No chat subscriptions yet.</div>`;
    } else {
      const allUsers = Store.users.get();
      subEl.innerHTML = recentSubs.map(s => {
        const viewer = allUsers.find(u=>u.id===s.viewerId);
        return `
          <div style="display:flex;align-items:center;gap:12px;padding:10px 0;border-bottom:1px solid var(--border)">
            <div class="avatar av-32" style="background:${viewer?.color||"#666"}22;color:${viewer?.color||"#666"}">${viewer?.avatar||"?"}</div>
            <div style="flex:1">
              <div style="font-size:13px;font-weight:600">${viewer?.name||"Unknown"}</div>
              <div class="text-muted text-xs">${UI.fmtDate(s.paidAt)}</div>
            </div>
            <span class="text-gold" style="font-weight:700">+$${s.price}</span>
          </div>`;
      }).join("");
    }
  }

  /* ── MY VIDEOS ───────────────────────────────────────────── */
  function renderMyVideos() {
    const user   = Auth.currentUser();
    const videos = VideoStore.byCreator(user.id).slice().reverse();
    const listEl = document.getElementById("cd-videos-list");

    if (!videos.length) {
      listEl.innerHTML = `
        <div style="text-align:center;padding:40px 20px">
          <div style="font-size:40px;margin-bottom:10px">🎬</div>
          <div style="font-weight:600;margin-bottom:6px">No videos yet</div>
          <div class="text-muted text-sm mb-16">Upload your first video to get started.</div>
          <button class="btn btn-primary" onclick="CreatorDash.section('cd-upload')">Upload Video</button>
        </div>`;
      return;
    }

    listEl.innerHTML = videos.map(v => `
      <div class="card vid-edit-card" style="margin-bottom:10px" id="vrow-${v.id}">
        <div class="vid-edit-thumb" style="background:${v.thumbColor}22;color:${v.thumbColor}">${v.thumbInitials}</div>
        <div class="vid-edit-info">
          <div class="vid-edit-title">${v.title}</div>
          <div class="vid-edit-meta">
            ${v.category} · ${UI.fmtNum(v.views)} views · ${UI.fmtDate(v.uploadedAt)}
          </div>
          <div style="display:flex;gap:6px;margin-top:6px;flex-wrap:wrap">
            ${v.published ? `<span class="badge badge-green">Published</span>` : `<span class="badge badge-muted">Draft</span>`}
            <span class="badge badge-${v.tier==="gold"?"gold":v.tier==="premium"?"purple":"muted"}">${v.tier}</span>
          </div>
        </div>
        <div class="vid-edit-actions">
          <button class="btn btn-ghost btn-xs" onclick="CreatorDash.editVideo('${v.id}')">✏️ Edit</button>
          <button class="btn btn-ghost btn-xs" onclick="CreatorDash.togglePublish('${v.id}')">${v.published?"Unpublish":"Publish"}</button>
          <button class="btn btn-danger btn-xs" onclick="CreatorDash.deleteVideo('${v.id}')">🗑️</button>
        </div>
      </div>`).join("");
  }

  function editVideo(id) {
    const v = VideoStore.byId(id);
    if (!v) return;
    const user = Auth.currentUser();

    const modal = document.getElementById("edit-video-modal");
    document.getElementById("ev-id").value          = v.id;
    document.getElementById("ev-title").value       = v.title;
    document.getElementById("ev-desc").value        = v.description;
    document.getElementById("ev-category").value    = v.category;
    document.getElementById("ev-tags").value        = (v.tags||[]).join(", ");
    modal.classList.add("open");
    document.body.style.overflow = "hidden";
  }

  function saveVideoEdit() {
    const user = Auth.currentUser();
    const id   = document.getElementById("ev-id").value;
    const tags = document.getElementById("ev-tags").value.split(",").map(t=>Security.sanitize(t.trim())).filter(Boolean);
    const res  = VideoStore.update(id, {
      title:       document.getElementById("ev-title").value.trim(),
      description: document.getElementById("ev-desc").value.trim(),
      category:    document.getElementById("ev-category").value.trim(),
      tags,
    }, user.id, user.role);
    if (res.ok) {
      document.getElementById("edit-video-modal").classList.remove("open");
      document.body.style.overflow = "";
      UI.toast("Video updated.", "success");
      renderMyVideos();
    } else {
      UI.toast(res.error, "error");
    }
  }

  function togglePublish(id) {
    const user = Auth.currentUser();
    const v    = VideoStore.byId(id);
    if (!v) return;
    VideoStore.update(id, { published: !v.published }, user.id, user.role);
    UI.toast(v.published ? "Video unpublished." : "Video published!", "success");
    renderMyVideos();
  }

  function deleteVideo(id) {
    const user = Auth.currentUser();
    UI.confirm("Delete this video permanently?", (yes) => {
      if (!yes) return;
      const res = VideoStore.remove(id, user.id, user.role);
      if (res.ok) { UI.toast("Video deleted.", "info"); renderMyVideos(); }
      else UI.toast(res.error, "error");
    });
  }

  /* ── UPLOAD ──────────────────────────────────────────────── */
  function renderUpload() {
    // reset form
    document.getElementById("upload-form").reset();
    document.getElementById("upload-file-name").textContent = "";
    document.getElementById("upload-progress").style.display = "none";
    document.getElementById("upload-progress-bar").style.width = "0%";
    _uploadedFile = null;
  }

  let _uploadedFile = null;

  function handleFileSelect(e) {
    const file = e.target.files[0];
    if (!file) return;
    const allowed = ["video/mp4","video/webm","video/ogg","video/quicktime","video/x-msvideo"];
    if (!allowed.includes(file.type)) {
      UI.toast("Only video files are accepted (MP4, WebM, MOV, AVI).", "error"); return;
    }
    if (file.size > 500 * 1024 * 1024) {
      UI.toast("File too large. Max 500MB.", "error"); return;
    }
    _uploadedFile = file;
    document.getElementById("upload-file-name").textContent = `${file.name} (${(file.size/1024/1024).toFixed(1)}MB)`;
  }

  async function submitUpload(e) {
    e.preventDefault();
    const user   = Auth.currentUser();
    const title  = document.getElementById("up-title").value.trim();
    const desc   = document.getElementById("up-desc").value.trim();
    const cat    = document.getElementById("up-category").value.trim();
    const tags   = document.getElementById("up-tags").value.split(",").map(t=>t.trim()).filter(Boolean);
    const errEl  = document.getElementById("upload-error");
    errEl.classList.remove("show");

    if (!title) { errEl.textContent = "Title is required."; errEl.classList.add("show"); return; }
    if (!_uploadedFile) { errEl.textContent = "Please select a video file."; errEl.classList.add("show"); return; }

    // Simulate upload progress
    const prog    = document.getElementById("upload-progress");
    const progBar = document.getElementById("upload-progress-bar");
    prog.style.display = "block";
    const btn = e.target.querySelector("button[type=submit]");
    btn.disabled = true; btn.textContent = "Uploading…";

    // Animate bar
    let pct = 0;
    const interval = setInterval(() => {
      pct = Math.min(pct + Math.random() * 15, 95);
      progBar.style.width = pct + "%";
    }, 200);
    await new Promise(r => setTimeout(r, 2500));
    clearInterval(interval);
    progBar.style.width = "100%";
    await new Promise(r => setTimeout(r, 300));

    // Estimate duration from file (rough: 1MB ~ 30s for 720p)
    const durSecs = Math.round((_uploadedFile.size / 1024 / 1024) * 8);
    const durStr  = durSecs >= 3600
      ? `${Math.floor(durSecs/3600)}:${String(Math.floor((durSecs%3600)/60)).padStart(2,"0")}:${String(durSecs%60).padStart(2,"0")}`
      : `${Math.floor(durSecs/60)}:${String(durSecs%60).padStart(2,"0")}`;

    const initials = title.split(" ").map(w=>w[0]?.toUpperCase()||"").slice(0,2).join("") || "VD";

    VideoStore.add({
      creatorId:     user.id,
      creatorName:   user.name,
      title, desc, category: cat, tags,
      fileName:      _uploadedFile.name,
      fileSize:      _uploadedFile.size,
      duration:      durStr,
      thumbColor:    user.color,
      thumbInitials: initials,
      description:   desc,
    });

    btn.disabled = false; btn.textContent = "Upload Video";
    prog.style.display = "none";
    _uploadedFile = null;
    document.getElementById("upload-form").reset();
    document.getElementById("upload-file-name").textContent = "";
    UI.toast("Video uploaded! It's now in draft. Publish it from My Videos.", "success");
    renderSection("cd-videos");
  }

  /* ── CREATOR MESSAGES ────────────────────────────────────── */
  function renderCreatorMessages() {
    const user     = Auth.currentUser();
    const subs     = SubStore.chatSubsForCreator(user.id);
    const allUsers = Store.users.get();
    const listEl   = document.getElementById("cd-msg-list");

    if (!subs.length) {
      listEl.innerHTML = `<div class="text-muted text-sm" style="padding:20px 0">No subscribers have messaged you yet.</div>`;
      document.getElementById("cd-msg-thread").style.display = "none";
      return;
    }

    const viewerIds = [...new Set(subs.map(s=>s.viewerId))];
    listEl.innerHTML = viewerIds.map(vid => {
      const viewer = allUsers.find(u=>u.id===vid);
      if (!viewer) return "";
      const thread  = Messaging.thread(user.id, vid);
      const last    = thread[thread.length-1];
      const unread  = thread.filter(m=>m.to===user.id&&!m.read).length;
      return `
        <div class="card card-hover" style="padding:14px;margin-bottom:8px;display:flex;align-items:center;gap:12px"
             onclick="CreatorDash.openMsgThread('${vid}')">
          <div class="avatar av-40" style="background:${viewer.color}22;color:${viewer.color}">${viewer.avatar}</div>
          <div style="flex:1;min-width:0">
            <div style="font-weight:600;font-size:14px">${viewer.name}</div>
            <div class="text-muted text-xs truncate">${last?last.text:"No messages yet"}</div>
          </div>
          ${unread ? `<span class="badge badge-gold">${unread}</span>` : ""}
        </div>`;
    }).join("");
  }

  let _msgThreadViewerId = null;

  function openMsgThread(viewerId) {
    _msgThreadViewerId = viewerId;
    const allUsers = Store.users.get();
    const viewer   = allUsers.find(u=>u.id===viewerId);
    const user     = Auth.currentUser();
    if (!viewer) return;

    const threadEl = document.getElementById("cd-msg-thread");
    threadEl.style.display = "flex";
    document.getElementById("cd-msg-thread-name").textContent = viewer.name;

    const msgs = Messaging.thread(user.id, viewerId);
    Messaging.markRead(viewerId, user.id);
    const box = document.getElementById("cd-msg-thread-box");
    box.innerHTML = `<div class="chat-sys">Private session</div>`;
    msgs.forEach(m => {
      const isMe = m.from === user.id;
      box.innerHTML += `
        <div class="msg-row ${isMe?"me":""}">
          <div class="bubble ${isMe?"me":"them"}">
            ${m.text}<div class="bubble-time">${UI.fmtTime(m.time)}</div>
          </div>
        </div>`;
    });
    box.scrollTop = box.scrollHeight;
  }

  function sendCreatorMsg() {
    const user  = Auth.currentUser();
    const input = document.getElementById("cd-msg-input");
    if (!_msgThreadViewerId || !input.value.trim()) return;
    Messaging.send(user.id, _msgThreadViewerId, input.value.trim());
    input.value = "";
    openMsgThread(_msgThreadViewerId);
  }

  /* ── EARNINGS ────────────────────────────────────────────── */
  function renderEarnings() {
    const user    = Auth.currentUser();
    const earns   = Store.earnings.get().filter(e=>e.creatorId===user.id);
    const total   = earns.reduce((s,e)=>s+e.amount,0);
    const allUsers= Store.users.get();

    document.getElementById("cd-total-earned").textContent  = `$${total.toFixed(2)}`;
    document.getElementById("cd-earn-count").textContent    = earns.length;
    document.getElementById("cd-pending-payout").textContent= `$${(total*0.8).toFixed(2)}`; // 80% after platform cut

    const tbody = document.getElementById("cd-earn-table");
    if (!earns.length) {
      tbody.innerHTML = `<tr><td colspan="4" class="text-muted text-sm" style="padding:16px">No earnings yet.</td></tr>`;
      return;
    }
    tbody.innerHTML = earns.slice().reverse().map(e => {
      const viewer = allUsers.find(u=>u.id===e.viewerId);
      return `
        <tr>
          <td>${UI.fmtDate(e.date)}</td>
          <td>${viewer?.name||"Unknown"}</td>
          <td><span class="badge badge-blue">${e.type}</span></td>
          <td class="text-gold" style="font-weight:700">+$${e.amount.toFixed(2)}</td>
        </tr>`;
    }).join("");
  }

  /* ── SETTINGS ────────────────────────────────────────────── */
  function renderCreatorSettings() {
    const user = Auth.currentUser();
    document.getElementById("cs-name").value      = user.name;
    document.getElementById("cs-bio").value       = user.bio || "";
    document.getElementById("cs-category").value  = user.category || "";
    document.getElementById("cs-chat-price").value= user.chatPrice || 10;
  }

  async function saveCreatorSettings(e) {
    e.preventDefault();
    const user  = Auth.currentUser();
    const price = parseFloat(document.getElementById("cs-chat-price").value);
    if (isNaN(price) || price < 1) { UI.toast("Chat price must be at least $1.", "error"); return; }

    Auth.updateProfile(user.id, {
      name:     document.getElementById("cs-name").value.trim(),
      bio:      document.getElementById("cs-bio").value.trim(),
      category: document.getElementById("cs-category").value.trim(),
    });
    // Save chatPrice separately
    const users = Store.users.get();
    const idx   = users.findIndex(u=>u.id===user.id);
    if (idx !== -1) { users[idx].chatPrice = price; Store.users.set(users); }

    UI.toast("Profile updated.", "success");
    renderNav();
  }

  function section(s) { renderSection(s); }

  return {
    init, section, editVideo, saveVideoEdit, togglePublish, deleteVideo,
    handleFileSelect, submitUpload,
    renderCreatorMessages, openMsgThread, sendCreatorMsg,
    saveCreatorSettings,
  };
})();


/* ═══════════════════════════════════════════════════════════════
   ADMIN DASHBOARD
═══════════════════════════════════════════════════════════════ */
const AdminDash = (() => {

  let _activeSection = "ad-overview";

  function init() {
    const user = Auth.currentUser();
    if (!user || user.role !== "admin") { Router.go("home"); return; }
    renderSection(_activeSection);
  }

  function renderSection(section) {
    _activeSection = section;
    document.querySelectorAll("#admin-dash-content .dash-section").forEach(s => {
      s.style.display = s.id === section ? "block" : "none";
    });
    document.querySelectorAll("#admin-sidebar .sidebar-btn").forEach(b => {
      b.classList.toggle("active", b.dataset.section === section);
    });
    const renders = {
      "ad-overview":  renderOverview,
      "ad-users":     renderUsers,
      "ad-videos":    renderAdminVideos,
      "ad-subs":      renderSubs,
      "ad-earnings":  renderAdminEarnings,
    };
    if (renders[section]) renders[section]();
  }

  /* ── OVERVIEW ────────────────────────────────────────────── */
  function renderOverview() {
    const users    = Store.users.get();
    const videos   = VideoStore.all();
    const subs     = SubStore.allSubs();
    const earnings = SubStore.earnings();
    const totalRev = earnings.reduce((s,e)=>s+e.amount,0);

    document.getElementById("ad-stat-users").textContent    = users.filter(u=>u.role!=="admin").length;
    document.getElementById("ad-stat-creators").textContent = users.filter(u=>u.role==="creator").length;
    document.getElementById("ad-stat-videos").textContent   = videos.length;
    document.getElementById("ad-stat-revenue").textContent  = `$${totalRev.toFixed(2)}`;

    // Recent signups
    const recentEl = document.getElementById("ad-recent-users");
    const recent   = users.filter(u=>u.role!=="admin").slice().reverse().slice(0,6);
    recentEl.innerHTML = recent.map(u=>`
      <div style="display:flex;align-items:center;gap:12px;padding:10px 0;border-bottom:1px solid var(--border)">
        <div class="avatar av-32" style="background:${u.color}22;color:${u.color}">${u.avatar}</div>
        <div style="flex:1">
          <div style="font-size:13px;font-weight:600">${u.name}</div>
          <div class="text-muted text-xs">${u.email} · ${u.role}</div>
        </div>
        <span class="badge badge-${u.active?"green":"red"}">${u.active?"Active":"Suspended"}</span>
      </div>`).join("") || `<div class="text-muted text-sm">No users yet.</div>`;

    // Pending / unpublished videos
    const pendingEl = document.getElementById("ad-pending-videos");
    const pending   = VideoStore.all().filter(v=>!v.published).slice().reverse().slice(0,5);
    pendingEl.innerHTML = pending.map(v=>`
      <div class="card vid-edit-card" style="margin-bottom:8px">
        <div class="vid-edit-thumb" style="background:${v.thumbColor}22;color:${v.thumbColor}">${v.thumbInitials}</div>
        <div class="vid-edit-info">
          <div class="vid-edit-title">${v.title}</div>
          <div class="vid-edit-meta">${v.creatorName} · ${UI.fmtDate(v.uploadedAt)}</div>
        </div>
        <div class="vid-edit-actions">
          <button class="btn btn-success btn-xs" onclick="AdminDash.publishVideo('${v.id}',true)">Publish</button>
          <button class="btn btn-danger btn-xs" onclick="AdminDash.flagVideo('${v.id}')">Flag</button>
        </div>
      </div>`).join("") || `<div class="text-muted text-sm">No pending videos.</div>`;
  }

  /* ── USERS ───────────────────────────────────────────────── */
  function renderUsers() {
    const users  = Store.users.get().filter(u=>u.role!=="admin");
    const tbody  = document.getElementById("ad-users-table");
    const search = document.getElementById("ad-user-search")?.value?.toLowerCase()||"";
    const filter = users.filter(u=>
      u.name.toLowerCase().includes(search)||
      u.email.toLowerCase().includes(search)
    );

    if (!filter.length) {
      tbody.innerHTML = `<tr><td colspan="6" class="text-muted text-sm" style="padding:16px">No users found.</td></tr>`;
      return;
    }
    tbody.innerHTML = filter.map(u=>`
      <tr>
        <td>
          <div style="display:flex;align-items:center;gap:10px">
            <div class="avatar av-32" style="background:${u.color}22;color:${u.color}">${u.avatar}</div>
            <div>
              <div style="font-weight:600;font-size:13px">${u.name}</div>
              <div class="text-muted text-xs">${u.email}</div>
            </div>
          </div>
        </td>
        <td><span class="badge badge-${u.role==="creator"?"blue":"muted"}">${u.role}</span></td>
        <td>${UI.fmtDate(u.joined)}</td>
        <td>${VideoStore.byCreator(u.id).length}</td>
        <td><span class="badge badge-${u.active?"green":"red"}">${u.active?"Active":"Suspended"}</span></td>
        <td>
          <div class="actions">
            <button class="btn btn-ghost btn-xs" onclick="AdminDash.toggleRole('${u.id}')">${u.role==="creator"?"→ Viewer":"→ Creator"}</button>
            <button class="btn btn-${u.active?"danger":"success"} btn-xs" onclick="AdminDash.toggleSuspend('${u.id}')">${u.active?"Suspend":"Restore"}</button>
          </div>
        </td>
      </tr>`).join("");
  }

  function toggleRole(uid) {
    const users = Store.users.get();
    const idx   = users.findIndex(u=>u.id===uid);
    if (idx===-1) return;
    users[idx].role = users[idx].role === "creator" ? "viewer" : "creator";
    Store.users.set(users);
    UI.toast("User role updated.", "success");
    renderUsers();
  }

  function toggleSuspend(uid) {
    const users = Store.users.get();
    const idx   = users.findIndex(u=>u.id===uid);
    if (idx===-1) return;
    const action = users[idx].active ? "suspend" : "restore";
    UI.confirm(`${action.charAt(0).toUpperCase()+action.slice(1)} this account?`, yes=>{
      if (!yes) return;
      users[idx].active = !users[idx].active;
      Store.users.set(users);
      UI.toast(`Account ${action}d.`, users[idx].active?"success":"info");
      renderUsers();
    });
  }

  /* ── VIDEOS ──────────────────────────────────────────────── */
  function renderAdminVideos() {
    const search = document.getElementById("ad-vid-search")?.value?.toLowerCase()||"";
    const tier   = document.getElementById("ad-vid-tier-filter")?.value||"all";
    let   videos = VideoStore.all();
    if (search) videos = videos.filter(v=>v.title.toLowerCase().includes(search)||v.creatorName.toLowerCase().includes(search));
    if (tier !== "all") videos = videos.filter(v=>v.tier===tier);
    videos = videos.slice().reverse();

    const tbody = document.getElementById("ad-videos-table");
    if (!videos.length) {
      tbody.innerHTML = `<tr><td colspan="7" class="text-muted text-sm" style="padding:16px">No videos found.</td></tr>`;
      return;
    }
    tbody.innerHTML = videos.map(v=>`
      <tr>
        <td>
          <div style="display:flex;align-items:center;gap:10px">
            <div class="avatar av-32" style="background:${v.thumbColor}22;color:${v.thumbColor}">${v.thumbInitials}</div>
            <div>
              <div style="font-weight:600;font-size:13px;max-width:180px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${v.title}</div>
              <div class="text-muted text-xs">${v.creatorName}</div>
            </div>
          </div>
        </td>
        <td>${UI.fmtDate(v.uploadedAt)}</td>
        <td>${UI.fmtNum(v.views)}</td>
        <td>
          <select class="input" style="width:100px;padding:4px 8px;font-size:12px" onchange="AdminDash.setTier('${v.id}',this.value)">
            <option value="free"   ${v.tier==="free"?"selected":""}>Free</option>
            <option value="gold"   ${v.tier==="gold"?"selected":""}>⭐ Gold</option>
            <option value="premium"${v.tier==="premium"?"selected":""}>💎 Premium</option>
          </select>
        </td>
        <td><span class="badge badge-${v.published?"green":"muted"}">${v.published?"Live":"Draft"}</span></td>
        <td><span class="badge badge-${v.flagged?"red":"muted"}">${v.flagged?"Flagged":"Clean"}</span></td>
        <td>
          <div class="actions">
            <button class="btn btn-${v.published?"ghost":"success"} btn-xs" onclick="AdminDash.publishVideo('${v.id}',${!v.published})">${v.published?"Unpublish":"Publish"}</button>
            <button class="btn btn-${v.flagged?"success":"danger"} btn-xs" onclick="AdminDash.flagVideo('${v.id}')">${v.flagged?"Unflag":"Flag"}</button>
            <button class="btn btn-danger btn-xs" onclick="AdminDash.deleteVideoAdmin('${v.id}')">🗑️</button>
          </div>
        </td>
      </tr>`).join("");
  }

  function setTier(id, tier) {
    const user = Auth.currentUser();
    VideoStore.update(id, { tier }, user.id, user.role);
    UI.toast(`Video tier set to "${tier}".`, "success");
  }

  function publishVideo(id, publish) {
    const user = Auth.currentUser();
    VideoStore.update(id, { published: publish }, user.id, user.role);
    UI.toast(publish ? "Video published." : "Video unpublished.", "success");
    renderAdminVideos();
    renderOverview();
  }

  function flagVideo(id) {
    const user = Auth.currentUser();
    const v    = VideoStore.byId(id);
    if (!v) return;
    VideoStore.update(id, { flagged: !v.flagged, published: v.flagged ? v.published : false }, user.id, user.role);
    UI.toast(v.flagged ? "Video unflagged." : "Video flagged and hidden.", v.flagged?"success":"info");
    renderAdminVideos();
    renderOverview();
  }

  function deleteVideoAdmin(id) {
    const user = Auth.currentUser();
    UI.confirm("Permanently delete this video?", yes=>{
      if (!yes) return;
      VideoStore.remove(id, user.id, user.role);
      UI.toast("Video deleted.", "info");
      renderAdminVideos();
    });
  }

  /* ── SUBSCRIPTIONS ───────────────────────────────────────── */
  function renderSubs() {
    const subs     = SubStore.allSubs().slice().reverse();
    const allUsers = Store.users.get();
    const tbody    = document.getElementById("ad-subs-table");

    if (!subs.length) {
      tbody.innerHTML = `<tr><td colspan="5" class="text-muted text-sm" style="padding:16px">No subscriptions yet.</td></tr>`;
      return;
    }
    tbody.innerHTML = subs.map(s=>{
      const viewer  = allUsers.find(u=>u.id===s.viewerId);
      const creator = s.creatorId ? allUsers.find(u=>u.id===s.creatorId) : null;
      const expired = Date.now() > s.expires;
      return `
        <tr>
          <td>${viewer?.name||"Unknown"}</td>
          <td>${creator?.name||"— (Premium)"}</td>
          <td><span class="badge badge-${s.type==="premium"?"purple":"blue"}">${s.type}</span></td>
          <td>$${s.price.toFixed(2)}</td>
          <td><span class="badge badge-${expired?"red":"green"}">${expired?"Expired":"Active"}</span></td>
        </tr>`;
    }).join("");
  }

  /* ── EARNINGS ────────────────────────────────────────────── */
  function renderAdminEarnings() {
    const earnings = SubStore.earnings().slice().reverse();
    const total    = earnings.reduce((s,e)=>s+e.amount,0);
    const platform = total * 0.2;

    document.getElementById("ad-total-revenue").textContent  = `$${total.toFixed(2)}`;
    document.getElementById("ad-platform-cut").textContent   = `$${platform.toFixed(2)}`;
    document.getElementById("ad-creator-payouts").textContent= `$${(total-platform).toFixed(2)}`;

    const allUsers = Store.users.get();
    const tbody    = document.getElementById("ad-earn-table");
    tbody.innerHTML = earnings.slice(0,50).map(e=>{
      const viewer  = allUsers.find(u=>u.id===e.viewerId);
      const creator = allUsers.find(u=>u.id===e.creatorId);
      return `
        <tr>
          <td>${UI.fmtDate(e.date)}</td>
          <td>${viewer?.name||"?"}</td>
          <td>${creator?.name||"Platform"}</td>
          <td><span class="badge badge-${e.type==="premium"?"purple":"blue"}">${e.type}</span></td>
          <td class="text-gold" style="font-weight:700">$${e.amount.toFixed(2)}</td>
        </tr>`;
    }).join("") || `<tr><td colspan="5" class="text-muted text-sm" style="padding:16px">No transactions yet.</td></tr>`;
  }

  function section(s) { renderSection(s); }

  return {
    init, section,
    renderUsers, toggleRole, toggleSuspend,
    renderAdminVideos, setTier, publishVideo, flagVideo, deleteVideoAdmin,
    renderSubs, renderAdminEarnings,
  };
})();
